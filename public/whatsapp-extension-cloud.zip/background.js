// background service worker — 處理 content script 的版本自檢消息
// 用 chrome action badge 顯示更新提示（工具欄圖標上的紅色 !），不接觸 WhatsApp 頁面 DOM 避免被風控

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || !msg.type) return;
  if (msg.type === 'update-available') {
    chrome.action.setBadgeText({ text: '!' });
    chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
    chrome.action.setTitle({
      title:
        'WhatsApp AI 客服扩展\n' +
        '當前版本：v' + (msg.current || '?') + '\n' +
        '最新版本：v' + (msg.latest || '?') + ' ⚠️ 有更新\n\n' +
        '請到 bizflow「設置/模式」tab 重新下載並重裝',
    });
  } else if (msg.type === 'update-cleared') {
    chrome.action.setBadgeText({ text: '' });
    chrome.action.setTitle({ title: 'WhatsApp AI 客服扩展' });
  }
});
