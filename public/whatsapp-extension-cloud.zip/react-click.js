// 运行在 MAIN world，可以访问 React 内部
document.addEventListener('wa-ai-react-click', function(e) {
  var selector = e.detail;
  var el = document.querySelector(selector);
  if (!el) {
    console.log('[WA-AI][react] element not found: ' + selector);
    return;
  }
  el.removeAttribute('data-wa-ai-click');

  // ── STEP 0: DOM pointer event 序列（2026-04 WhatsApp Web 新 React 內部方法失效後的首選）──
  // 派發真實的 pointerover → pointerdown → pointerup → click，React synthetic event 會正常捕獲
  try {
    var rect = el.getBoundingClientRect();
    var cx = rect.left + rect.width / 2;
    var cy = rect.top + rect.height / 2;
    var base = { bubbles: true, cancelable: true, view: window, button: 0, clientX: cx, clientY: cy };
    var downP = Object.assign({}, base, { buttons: 1, pointerType: 'mouse', pointerId: 1, isPrimary: true });
    var upP   = Object.assign({}, base, { buttons: 0, pointerType: 'mouse', pointerId: 1, isPrimary: true });
    el.dispatchEvent(new PointerEvent('pointerover', downP));
    el.dispatchEvent(new PointerEvent('pointerenter', downP));
    el.dispatchEvent(new PointerEvent('pointerdown', downP));
    el.dispatchEvent(new MouseEvent('mousedown', Object.assign({}, base, { buttons: 1 })));
    el.dispatchEvent(new PointerEvent('pointerup', upP));
    el.dispatchEvent(new MouseEvent('mouseup', Object.assign({}, base, { buttons: 0 })));
    el.dispatchEvent(new MouseEvent('click', Object.assign({}, base, { buttons: 0 })));
    console.log('[WA-AI][react] SUCCESS: pointer-event sequence dispatched');
    return;
  } catch (err) {
    console.log('[WA-AI][react] pointer-event failed, falling back to fiber: ' + err.message);
  }

  // 找 React fiber
  function getFiber(node) {
    var keys = Object.keys(node);
    for (var i = 0; i < keys.length; i++) {
      if (keys[i].startsWith('__reactFiber$') || keys[i].startsWith('__reactInternalInstance$')) {
        return node[keys[i]];
      }
    }
    return null;
  }

  var rootFiber = getFiber(el);
  if (!rootFiber) {
    var children = el.querySelectorAll('*');
    for (var c = 0; c < children.length; c++) {
      rootFiber = getFiber(children[c]);
      if (rootFiber) break;
    }
  }
  if (!rootFiber) {
    console.log('[WA-AI][react] no fiber found');
    return;
  }

  // 向下遍历 fiber 树，找有 props.chat 的组件
  function findChatFiber(fiber, depth) {
    if (!fiber || depth > 30) return null;
    var props = fiber.memoizedProps || {};
    if (props.chat && props.chat.id) return fiber;
    // 检查 stateNode（class 组件的实例）
    if (fiber.stateNode && fiber.stateNode.props) {
      var sp = fiber.stateNode.props;
      if (sp.chat && sp.chat.id) return fiber;
    }
    var child = fiber.child;
    while (child) {
      var result = findChatFiber(child, depth + 1);
      if (result) return result;
      child = child.sibling;
    }
    return null;
  }

  // 从 chat fiber 向下找 onMouseDown handler
  function findMouseDownFiber(fiber, depth) {
    if (!fiber || depth > 15) return null;
    var props = fiber.memoizedProps || {};
    if (typeof props.onMouseDown === 'function') return fiber;
    var child = fiber.child;
    while (child) {
      var result = findMouseDownFiber(child, depth + 1);
      if (result) return result;
      child = child.sibling;
    }
    return null;
  }

  // 1. 找 chat 组件
  var chatFiber = findChatFiber(rootFiber, 0);
  if (!chatFiber) {
    console.log('[WA-AI][react] no chat fiber found, trying parent');
    // 也往上找
    var f = rootFiber.return;
    var d = 0;
    while (f && d < 20) {
      var p = f.memoizedProps || {};
      if (p.chat && p.chat.id) { chatFiber = f; break; }
      if (f.stateNode && f.stateNode.props && f.stateNode.props.chat) { chatFiber = f; break; }
      f = f.return;
      d++;
    }
  }

  if (!chatFiber) {
    console.log('[WA-AI][react] no chat component found anywhere');
    return;
  }

  var chatProps = chatFiber.stateNode ? chatFiber.stateNode.props : chatFiber.memoizedProps;
  console.log('[WA-AI][react] found chat: ' + (chatProps.chat.name || chatProps.chat.formattedTitle || chatProps.chat.id));

  // 2. 找 stateNode 上的内部点击方法（$20 或类似）
  var instance = chatFiber.stateNode;
  if (instance) {
    // 找所有以 $ 开头的方法，调用那个接收单个 event 参数且内部调 props.onClick 的
    // $20 的特征：function(e) { var t = i.props; ... t.onClick ... }
    // $21 的特征：function(e) { e.button === 0 && ... }
    // 直接尝试找这些方法
    var fakeEvt = new MouseEvent('mousedown', {
      bubbles: true, cancelable: true, view: window, button: 0, buttons: 1
    });
    // 加上 React 需要的方法
    fakeEvt.persist = function() {};
    fakeEvt.isDefaultPrevented = function() { return false; };
    fakeEvt.isPropagationStopped = function() { return false; };

    // 尝试找内部的 click handler 方法
    var keys = Object.keys(instance);
    var clickMethods = [];
    for (var k = 0; k < keys.length; k++) {
      var key = keys[k];
      if (key.startsWith('$') && typeof instance[key] === 'function') {
        var fnStr = instance[key].toString();
        // $21: function(e) { e.button === 0 && i.$20(e) }
        if (fnStr.indexOf('.button') !== -1 && fnStr.indexOf('=== 0') !== -1) {
          clickMethods.unshift({ key: key, fn: instance[key], type: 'mousedown-check' });
        }
        // $20: function(e) { ... props ... onClick ... }
        if (fnStr.indexOf('onClick') !== -1 && fnStr.indexOf('props') !== -1 && fnStr.indexOf('chat') !== -1) {
          clickMethods.push({ key: key, fn: instance[key], type: 'click-proxy' });
        }
      }
    }

    if (clickMethods.length > 0) {
      console.log('[WA-AI][react] found ' + clickMethods.length + ' internal methods: ' +
        clickMethods.map(function(m) { return m.key + '(' + m.type + ')'; }).join(', '));
      for (var m = 0; m < clickMethods.length; m++) {
        try {
          clickMethods[m].fn(fakeEvt);
          console.log('[WA-AI][react] SUCCESS: called ' + clickMethods[m].key);
          return;
        } catch (err) {
          console.log('[WA-AI][react] ' + clickMethods[m].key + ' error: ' + err.message);
        }
      }
    }
  }

  // 3. fallback: 找子节点的 onMouseDown
  var mdFiber = findMouseDownFiber(chatFiber, 0);
  if (mdFiber) {
    var handler = mdFiber.memoizedProps.onMouseDown;
    var fakeEvt2 = new MouseEvent('mousedown', {
      bubbles: true, cancelable: true, view: window, button: 0, buttons: 1
    });
    fakeEvt2.persist = function() {};
    fakeEvt2.isDefaultPrevented = function() { return false; };
    fakeEvt2.isPropagationStopped = function() { return false; };
    try {
      handler(fakeEvt2);
      console.log('[WA-AI][react] SUCCESS: called onMouseDown from child fiber');
      return;
    } catch (err) {
      console.log('[WA-AI][react] onMouseDown error: ' + err.message);
    }
  }

  // 4. 最终 fallback: 用 chat 对象手动调父组件的 onItemClick
  console.log('[WA-AI][react] trying onItemClick with chat object');
  var f2 = chatFiber.return;
  var d2 = 0;
  while (f2 && d2 < 20) {
    var p2 = f2.memoizedProps || {};
    if (typeof p2.onItemClick === 'function' && chatProps.chat) {
      var fakeEvt3 = new MouseEvent('click', { bubbles: true, button: 0 });
      fakeEvt3.persist = function() {};
      fakeEvt3.isDefaultPrevented = function() { return false; };
      fakeEvt3.isPropagationStopped = function() { return false; };
      try {
        p2.onItemClick(fakeEvt3, chatProps.chat);
        console.log('[WA-AI][react] SUCCESS: called onItemClick with chat');
        return;
      } catch (err) {
        console.log('[WA-AI][react] onItemClick error: ' + err.message);
      }
    }
    f2 = f2.return;
    d2++;
  }

  console.log('[WA-AI][react] all attempts failed');
});

console.log('[WA-AI][react-click] main world script loaded');
