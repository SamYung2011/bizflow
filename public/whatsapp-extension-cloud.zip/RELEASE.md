# 雲端版扩展發版流程

每次扩展功能更新，按以下順序操作：

## 1. 改 3 處版本號（必須一致）

```
chrome-extension-cloud/manifest.json  →  "version": "1.1"
chrome-extension-cloud/manifest.json  →  "name": "WhatsApp AI 客服 (雲端) v1.1"
bizflow_lazy/src/App.jsx              →  const LATEST_EXT_VERSION = "1.1"
```

> ⚠️ 三處不一致時：
> - `manifest.version` 是 chrome 認的官方版本（chrome://extensions 顯示）
> - `manifest.name` 是讓使用者一眼看到的版本（chrome://extensions / 載入時的命名）
> - `LATEST_EXT_VERSION` 是 bizflow 用來跟扩展心跳的 `version` 對比，落後就紅字提示

## 2. 重新打 zip

```powershell
$src = 'F:\Claude_demo\whatsapp_api\chrome-extension-cloud'
$dst = 'F:\Claude_demo\whatsapp_api\whatsapp-extension-cloud.zip'
if (Test-Path $dst) { Remove-Item $dst }
Compress-Archive -Path "$src\*" -DestinationPath $dst -Force
```

## 3. 同步 zip 到 bizflow public/（兩個目錄）

```bash
cp /f/Claude_demo/whatsapp_api/whatsapp-extension-cloud.zip /f/Claude_demo/bizflow_lazy/public/
cp /f/Claude_demo/whatsapp_api/whatsapp-extension-cloud.zip /f/Claude_demo/bizflow_samyung/public/
```

## 4. 同步源碼到兩個 git 倉庫

```bash
# bizflow_lazy 不是 git，是煊煊本地副本，必須 cp 到 bizflow_samyung 才能 push
cp /f/Claude_demo/bizflow_lazy/src/App.jsx /f/Claude_demo/bizflow_samyung/src/App.jsx
cp /f/Claude_demo/bizflow_lazy/src/i18n.jsx /f/Claude_demo/bizflow_samyung/src/i18n.jsx

# 扩展源碼也鏡像到 WhatsApp_repo/v3.5/
cp -r /f/Claude_demo/whatsapp_api/chrome-extension-cloud/* /f/Claude_demo/WhatsApp_repo/v3.5/chrome-extension-cloud/
```

## 5. push 兩個倉庫

```bash
# bizflow（連帶觸發 Vercel 部署）
git -C /f/Claude_demo/bizflow_samyung add public/whatsapp-extension-cloud.zip src/App.jsx src/i18n.jsx
git -C /f/Claude_demo/bizflow_samyung commit -m "扩展 v1.1: ..."
git -C /f/Claude_demo/bizflow_samyung push

# WhatsApp_repo
git -C /f/Claude_demo/WhatsApp_repo add v3.5/chrome-extension-cloud/
git -C /f/Claude_demo/WhatsApp_repo commit -m "v3.5 cloud extension: v1.1 ..."
git -C /f/Claude_demo/WhatsApp_repo push
```

## 6. 通知老板更新

老板登 bizflow → WhatsApp tab → 切到 API 雲端模式 → 看到狀態卡上他的版本落後 v0.X ⚠️ → v1.1 紅字提示 → 點「📖 查看安裝教程」→ 按「更新版本」步驟操作。

> 自動心跳每 15s 在 bizflow 端 refetch，老板的扩展啟動後 30s 內就會上報新心跳，但 chrome 內部還是舊版（除非他真重新載入）。

## 不要做的事

- 別把 zip 上傳到 Supabase Storage（之前試過卡 RLS，A 方案 bizflow public/ 由 Vercel serve 最簡單）
- 別 fork 第二個雲端版扩展，改現有的就行
- 別動 chrome-extension/（本地版），那是煊煊調試用的，跟雲端版獨立
