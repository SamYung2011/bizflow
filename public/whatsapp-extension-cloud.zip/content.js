(function() {
  // 雲端版：直接打 Supabase Edge Functions + REST。anon key 是 public 的（RLS 控制權限）
  var SUPABASE_URL = 'https://bizflow.honnmono.top';
  var SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlIiwiaWF0IjoxNzc3NDUyMzQ5LCJleHAiOjE5MzUxMzIzNDl9.MUSPKYLYD74rvqogokIpPcBEldA_RTbNBbMeDW_AZxs';
  function sbFetch(path, opts) {
    opts = opts || {};
    opts.headers = Object.assign({
      apikey: SUPABASE_ANON_KEY,
      Authorization: 'Bearer ' + SUPABASE_ANON_KEY,
      'Content-Type': 'application/json'
    }, opts.headers || {});
    return fetch(SUPABASE_URL + path, opts);
  }
  var POLL_INTERVAL = 3000;
  var UNREAD_CHECK_INTERVAL = 4000;
  var REPLY_POLL_INTERVAL = 3000;       // 短輪詢 wa_replies 間隔
  var HEARTBEAT_INTERVAL = 5000;        // wa_clients 心跳：5s 一次（bizflow 在線狀態容忍網絡抖動，閾值 15s = 容忍 2 次丟失）

  // 客戶端 ID（持久化在 localStorage，跨刷新保留）
  var CLIENT_ID = null;
  try { CLIENT_ID = localStorage.getItem('wa_ai_client_id'); } catch(e) {}
  if (!CLIENT_ID) {
    CLIENT_ID = 'cloud-' + Math.random().toString(36).slice(2, 10) + '-' + Date.now().toString(36);
    try { localStorage.setItem('wa_ai_client_id', CLIENT_ID); } catch(e) {}
  }
  var EXT_VERSION = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest)
    ? chrome.runtime.getManifest().version : 'unknown';
  var UA_SHORT = (function() {
    var ua = navigator.userAgent || '';
    var m = ua.match(/(Chrome|Edge|Firefox|Safari)\/([\d.]+)/);
    var os = /Windows/.test(ua) ? 'Win' : /Mac/.test(ua) ? 'Mac' : /Linux/.test(ua) ? 'Linux' : '?';
    return (m ? m[1] + ' ' + m[2].split('.')[0] : 'Browser') + ' / ' + os;
  })();

  function sendHeartbeat() {
    sbFetch('/rest/v1/wa_clients', {
      method: 'POST',
      headers: { 'Prefer': 'return=minimal,resolution=merge-duplicates' },
      body: JSON.stringify({
        client_id: CLIENT_ID,
        mode: 'cloud',
        version: EXT_VERSION,
        ua: UA_SHORT,
        last_seen: new Date().toISOString()
      })
    }).catch(function(e) { log('heartbeat-err', e.message); });
  }
  // 持久化已处理消息ID，防止刷新后重复发送
  var _savedIds = [];
  try { _savedIds = JSON.parse(localStorage.getItem('wa_ai_processed') || '[]'); } catch(e) {}
  var processedIds = new Set(_savedIds);
  function _saveProcessedIds() {
    var arr = Array.from(processedIds);
    if (arr.length > 3000) arr = arr.slice(-2000);
    try { localStorage.setItem('wa_ai_processed', JSON.stringify(arr)); } catch(e) {}
  }
  var lastPollTime = 0;
  var isSwitching = false;
  var currentChatName = '';
  // 等待回复机制：checkUnreadChats 等 AI 回复发完再处理下一个
  var waitingForReply = null;  // 正在等回复的聊天名
  var replyDoneResolve = null; // resolve 函数，pollReplies 调用来通知回复完成
  // 白名单：从服务端加载，只有白名单内的聊天才自动点入
  var whitelistPhones = [];        // 私聊手机号，如 ['85296577813']
  var whitelistGroups = [];        // 群聊精确匹配群名
  var whitelistGroupsFuzzy = [];   // 群聊模糊匹配关键词（小写）
  var whitelistLoaded = false;

  // 雲端版：boss_chat_name 從 wa_settings 拿，雲端**不處理老板對話**（bizflow 已標註不支持日報/Boss Prompt）
  // boss 在這裡只用來「跳過老板私聊不發給雲端 AI」，避免老板隱私上雲
  var bossChatName = '';
  function loadWhitelist() {
    Promise.all([
      sbFetch('/rest/v1/wa_whitelist?active=eq.true&select=kind,value').then(function(r) { return r.json(); }),
      sbFetch('/rest/v1/wa_settings?id=eq.1&select=boss_chat_name').then(function(r) { return r.json(); })
    ]).then(function(arr) {
      var wl = arr[0] || [];
      var settings = (arr[1] && arr[1][0]) || {};
      whitelistPhones = wl.filter(function(w) { return w.kind === 'phone'; })
        .map(function(w) { return (w.value || '').replace(/[^0-9]/g, ''); }).filter(Boolean);
      whitelistGroups = wl.filter(function(w) { return w.kind === 'group'; })
        .map(function(w) { return w.value; }).filter(Boolean);
      whitelistGroupsFuzzy = wl.filter(function(w) { return w.kind === 'group_fuzzy'; })
        .map(function(w) { return (w.value || '').toLowerCase(); }).filter(Boolean);
      bossChatName = (settings.boss_chat_name || '').trim();
      whitelistLoaded = true;
      log('whitelist', 'phones=[' + whitelistPhones.join(',') + '] groups=[' + whitelistGroups.join(',') + '] fuzzy=[' + whitelistGroupsFuzzy.join(',') + '] boss=[' + bossChatName + ']');
    }).catch(function(e) { log('whitelist', 'load failed: ' + e.message); });
  }

  function isWhitelisted(chatName) {
    log('whitelist-debug', 'checking: [' + chatName + '] lower=[' + chatName.toLowerCase() + '] fuzzy=' + JSON.stringify(whitelistGroupsFuzzy));
    // 白名单全空 = 允许所有
    if (whitelistPhones.length === 0 && whitelistGroups.length === 0 && whitelistGroupsFuzzy.length === 0) return true;
    var nameDigits = chatName.replace(/[^0-9]/g, '');
    var nameLower = chatName.toLowerCase();
    // 私聊：手机号匹配
    for (var i = 0; i < whitelistPhones.length; i++) {
      if (nameDigits && nameDigits.indexOf(whitelistPhones[i]) !== -1) return true;
      if (nameDigits && whitelistPhones[i].indexOf(nameDigits) !== -1) return true;
    }
    // 群聊：精确匹配群名
    for (var j = 0; j < whitelistGroups.length; j++) {
      if (chatName === whitelistGroups[j]) return true;
    }
    // 群聊：模糊匹配（包含即命中）
    for (var k = 0; k < whitelistGroupsFuzzy.length; k++) {
      if (nameLower.indexOf(whitelistGroupsFuzzy[k]) !== -1) return true;
    }
    return false;
  }

  function log(tag) {
    var args = Array.prototype.slice.call(arguments, 1);
    console.log('[WA-AI][' + tag + ']', args.join(' '));
  }

  function sleep(ms) {
    return new Promise(function(r) { setTimeout(r, ms); });
  }

  // 抠位置消息的 lat/lng + 地点名 + 地址
  // 三个识别特征（按可靠性排）：
  //   1) <img src="...maps/api/staticmap?...&markers=color:red|<lat>,<lng>">
  //   2) <a href="https://maps.google.com/maps/search/.../@<lat>,<lng>,17z">
  //   3) aria-label 含「地图 / 位置 / map / location」（语言相关，仅做信号增强）
  function parseLocationFromEl(el) {
    var lat = null, lng = null;
    // 1) staticmap img（最稳）
    var img = el.querySelector('img[src*="staticmap"]');
    if (img) {
      var src = img.getAttribute('src') || '';
      var m = src.match(/markers=[^&]*?(?:%7C|\|)(-?\d+\.\d+)(?:%2C|,)\+?(-?\d+\.\d+)/);
      if (m) { lat = parseFloat(m[1]); lng = parseFloat(m[2]); }
    }
    // 2) Google Maps 链接 @lat,lng
    if (lat === null) {
      var a = el.querySelector('a[href*="maps.google.com"]');
      if (a) {
        var href = a.getAttribute('href') || '';
        var m2 = href.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
        if (m2) { lat = parseFloat(m2[1]); lng = parseFloat(m2[2]); }
      }
    }
    if (lat === null || lng === null) return null;
    var placeName = '';
    var address = '';
    var nameLinks = el.querySelectorAll('a[href*="maps.google.com"]');
    if (nameLinks.length >= 2) {
      placeName = (nameLinks[1].innerText || '').trim();
    }
    var addrEl = el.querySelector('div[title]');
    if (addrEl) address = (addrEl.getAttribute('title') || '').trim();
    return { lat: lat, lng: lng, placeName: placeName, address: address };
  }

  function getVisibleMessages() {
    var messages = [];
    // 只扫主聊天区的消息，避免侧边栏干扰
    // WhatsApp 2024+ data-id 变成纯 hex 不带下划线，同时带 data-testid="conv-msg-xxx"
    var main = document.querySelector('#main');
    if (!main) return messages;
    var msgElements = main.querySelectorAll('[data-id]');
    msgElements.forEach(function(el) {
      var dataId = el.getAttribute('data-id');
      if (!dataId) return;
      // 系統消息過濾（端到端加密提示、加入/離開群組、刪除消息、設為管理員等）
      // 系統消息沒 .message-in / .message-out / [data-pre-plain-text]，正常消息至少有一個
      var hasIn = !!el.querySelector('.message-in');
      var hasOut = !!el.querySelector('.message-out');
      var hasPre = !!el.querySelector('[data-pre-plain-text]');
      if (!hasIn && !hasOut && !hasPre) return;
      // 先识别位置消息（位置消息的 .selectable-text 里也有 URL 文本，会盖掉真意图）
      var location = parseLocationFromEl(el);
      var textEl = el.querySelector('.selectable-text') || el.querySelector('span[dir="ltr"]') || el.querySelector('span[dir="rtl"]');
      var text = '';
      if (textEl) {
        text = textEl.innerText;
      } else {
        // fallback：从 copyable-text 容器提取
        var copyable = el.querySelector('[data-pre-plain-text]');
        if (copyable) text = copyable.innerText;
      }
      // 位置消息：用人类可读的描述替换 text（不丢这条消息）
      if (location) {
        text = '[位置消息] ' + (location.placeName || (location.lat.toFixed(5) + ',' + location.lng.toFixed(5)));
      }
      if (!text || !text.trim()) return;
      text = text.trim();
      var fromMe = dataId.indexOf('true_') === 0 || !!el.querySelector('.message-out');
      var sender = '';
      var senderEl = el.querySelector('[data-pre-plain-text]');
      if (senderEl) {
        var pre = senderEl.getAttribute('data-pre-plain-text') || '';
        var match = pre.match(/\]\s*(.+?):/);
        if (match) sender = match[1].trim();
      }
      var msgObj = { id: dataId, text: text, fromMe: fromMe, sender: sender };
      if (location) msgObj.location = location;
      messages.push(msgObj);
    });
    return messages;
  }

  function getCurrentChat() {
    // 聊天区 header 在 #main 里，不要匹配侧边栏的 header
    var main = document.querySelector('#main');
    if (!main) return null;
    var header = main.querySelector('header');
    if (!header) return null;
    // 优先取 title 属性（更可靠），再取 innerText
    var titleEl = header.querySelector('span[dir="auto"][title]')
      || header.querySelector('span[dir="auto"]');
    var title = '';
    if (titleEl) {
      title = (titleEl.getAttribute('title') || titleEl.innerText || '').trim();
    }
    return { title: title };
  }

  function getUnreadChats() {
    var unreadChats = [];
    // 兼容多种 WhatsApp Web 版本的选择器
    var chatItems = document.querySelectorAll('#pane-side [role="listitem"]');
    if (chatItems.length === 0) {
      chatItems = document.querySelectorAll('#pane-side [data-testid="cell-frame-container"]');
    }
    if (chatItems.length === 0) {
      chatItems = document.querySelectorAll('#pane-side > div > div > div > div');
    }
    chatItems.forEach(function(item) {
      var unreadCount = 0;
      // 優先：data-testid="icon-unread-count" 是 WhatsApp Web 權威未讀 badge
      //  - 裡面有數字 → 讀數字
      //  - 裡面空（只顯示小圓點） → 至少 1 條
      var badgeEl = item.querySelector('[data-testid="icon-unread-count"]');
      if (badgeEl) {
        var badgeText = (badgeEl.innerText || '').trim();
        var bm = badgeText.match(/\d+/);
        unreadCount = bm ? parseInt(bm[0]) : 1;
      }
      // Fallback：老版 WhatsApp Web 用純 span 數字徽章
      if (unreadCount <= 0) {
        var spans = item.querySelectorAll('span');
        for (var s = 0; s < spans.length; s++) {
          var t = (spans[s].innerText || '').trim();
          if (t && /^\d+$/.test(t)) {
            var num = parseInt(t);
            var rect = spans[s].getBoundingClientRect();
            if (num > 0 && num < 1000 && rect.width < 50 && rect.height < 50) {
              unreadCount = num;
              break;
            }
          }
        }
      }
      if (unreadCount <= 0) return;
      // 获取聊天名称
      var nameEl = item.querySelector('span[dir="auto"][title]');
      if (!nameEl) nameEl = item.querySelector('span[title]');
      var name = nameEl ? (nameEl.getAttribute('title') || nameEl.innerText || '').trim() : '';
      if (name) {
        unreadChats.push({ element: item, name: name, unreadCount: unreadCount });
      }
    });
    // 诊断日志：每次扫描都报告结果
    if (unreadChats.length > 0) {
      log('scan', 'unread: ' + unreadChats.map(function(c) { return c.name + '(' + c.unreadCount + ')'; }).join(', '));
    } else if (chatItems.length > 0) {
      // 每30秒打一次"无未读"，避免刷屏
      var now = Date.now();
      if (!getUnreadChats._lastNoUnread || now - getUnreadChats._lastNoUnread > 30000) {
        getUnreadChats._lastNoUnread = now;
        log('scan', 'no unread in ' + chatItems.length + ' chats');
      }
    } else {
      log('scan-warn', 'sidebar empty — selectors may not match current WhatsApp Web DOM');
    }
    return unreadChats;
  }

  function clickViaReact(el) {
    // 通过 CustomEvent 让 MAIN world 的 react-click.js 处理
    var id = 'wa_ai_' + Date.now();
    el.setAttribute('data-wa-ai-click', id);
    var selector = '[data-wa-ai-click="' + id + '"]';
    document.dispatchEvent(new CustomEvent('wa-ai-react-click', { detail: selector }));
  }

  async function switchToChat(chatItem) {
    log('switch', 'clicking via React fiber: ' + chatItem.name);
    clickViaReact(chatItem.element);
    await sleep(2000);
    var chat = getCurrentChat();
    if (chat && chat.title) {
      currentChatName = chat.title;
      log('switch', 'entered chat: ' + chat.title);
      return true;
    }
    // 二次尝试：对内部 div 调 React
    var innerDiv = chatItem.element.querySelector('div[tabindex="-1"]') || chatItem.element.querySelector('div');
    if (innerDiv) {
      log('switch', 'retrying on inner div');
      clickViaReact(innerDiv);
      await sleep(2000);
      chat = getCurrentChat();
      if (chat && chat.title) {
        currentChatName = chat.title;
        log('switch', 'entered chat: ' + chat.title);
        return true;
      }
    }
    log('switch', 'failed');
    return false;
  }

  // 点击自己发过的消息来清除未读标记
  async function clearUnreadBadge() {
    log('clear', 'clicking own message to clear unread badge');
    var main = document.querySelector('#main');
    if (!main) return;
    // 方法1：找 aria-label="你：" 的 span（自己发的消息标识）
    var myMsgLabel = main.querySelector('span[aria-label="你："]')
      || main.querySelector('span[aria-label="You:"]')
      || main.querySelector('span[aria-label="你: "]')
      || main.querySelector('span[aria-label="You: "]');
    if (myMsgLabel) {
      // 点击这个 span 的父消息容器
      var msgRow = myMsgLabel.closest('[data-id]') || myMsgLabel.closest('.message-out') || myMsgLabel.parentElement;
      if (msgRow) {
        msgRow.click();
        log('clear', 'clicked own message row');
        await sleep(500);
        return;
      }
    }
    // 方法2：找 .message-out（自己发的消息）
    var myMsgs = main.querySelectorAll('.message-out');
    if (myMsgs.length > 0) {
      var lastMyMsg = myMsgs[myMsgs.length - 1];
      lastMyMsg.click();
      log('clear', 'clicked last .message-out');
      await sleep(500);
      return;
    }
    // 方法3：点聊天区域空白处
    var msgArea = main.querySelector('.copyable-area') || main;
    msgArea.click();
    log('clear', 'clicked chat area (fallback)');
    await sleep(500);
  }

  async function checkUnreadChats() {
    if (!whitelistLoaded) {
      log('skip', 'whitelist not loaded yet');
      return;
    }
    if (isSwitching || waitingForReply) {
      return; // 正在切换或等回复，跳过
    }
    var unreadChats = getUnreadChats();
    if (unreadChats.length === 0) return;
    // 白名单过滤
    var filtered = unreadChats.filter(function(c) { return isWhitelisted(c.name); });
    var skipped = unreadChats.length - filtered.length;
    if (skipped > 0) log('whitelist', 'skipped ' + skipped + ' non-whitelisted chat(s)');
    if (filtered.length === 0) return;

    // 一次只处理第一个未读聊天
    var chat = filtered[0];
    log('scan', 'processing: ' + chat.name + ' (' + chat.unreadCount + ' unread)');
    isSwitching = true;

    try {
      var switched = await switchToChat(chat);
      if (!switched) {
        log('error', 'failed to switch to ' + chat.name);
        return;
      }
      await sleep(1000);
      var newMsgs = await pollMessages(chat.unreadCount);

      if (newMsgs > 0) {
        // 有新消息发给了服务端，等 AI 回复
        log('wait', 'sent ' + newMsgs + ' msg(s), waiting for AI reply...');
        waitingForReply = chat.name;

        // 创建 Promise，pollReplies 发完回复后 resolve
        var replyDone = new Promise(function(resolve) {
          replyDoneResolve = resolve;
          // 超时 120 秒自动放行（防止永久卡住）
          setTimeout(function() { resolve('timeout'); }, 120000);
        });

        // 释放 isSwitching 让其他流程不被完全阻塞
        isSwitching = false;

        var result = await replyDone;
        if (result === 'timeout') {
          log('wait', 'reply timeout after 120s, moving on');
        } else {
          log('wait', 'reply sent, clearing unread badge');
        }
        replyDoneResolve = null;
      }

      // 回复完成（或无需回复），清除未读标记
      await clearUnreadBadge();
      waitingForReply = null;

    } catch (err) {
      log('error', 'checkUnreadChats crashed: ' + err.message);
    } finally {
      isSwitching = false;
      waitingForReply = null;
      replyDoneResolve = null;
    }
  }

  function randInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  function isPunct(ch) {
    return ',.!?;:()'.indexOf(ch) !== -1;
  }

  function findInputBox() {
    // WhatsApp Web 主聊天输入框，必须在 footer 内（排除附件区域的输入框）
    var footer = document.querySelector('footer');
    if (footer) {
      var box = footer.querySelector('div[role="textbox"][contenteditable="true"]')
        || footer.querySelector('[contenteditable="true"]');
      if (box) return box;
    }
    // fallback
    return document.querySelector('div[role="textbox"][contenteditable="true"][data-tab]');
  }

  function findSendButton() {
    // 只找明确的发送按钮，绝不 fallback 到其他按钮
    var btn = document.querySelector('button[aria-label="Send"]')
      || document.querySelector('button[aria-label="\u53D1\u9001"]');
    if (btn) return btn;
    var icon = document.querySelector('span[data-icon="send"]');
    if (icon) {
      btn = icon.closest('button');
      if (btn) return btn;
    }
    return null;
  }

  async function sendMessage(text) {
    var input = findInputBox();
    if (!input) {
      log('error', 'input box not found');
      return false;
    }
    log('input', 'found: tag=' + input.tagName + ' tab=' + input.getAttribute('data-tab'));
    input.focus();
    await sleep(300);

    // 逐字输入，模拟真人打字
    for (var i = 0; i < text.length; i++) {
      var char = text[i];
      if (char === '\n') {
        var shiftEnter = new KeyboardEvent('keydown', {
          key: 'Enter', code: 'Enter', keyCode: 13,
          shiftKey: true, bubbles: true
        });
        input.dispatchEvent(shiftEnter);
        await sleep(randInt(100, 300));
      } else {
        document.execCommand('insertText', false, char);
        if (isPunct(char)) {
          await sleep(randInt(150, 400));
        } else {
          await sleep(randInt(30, 100));
        }
      }
    }
    await sleep(randInt(300, 600));

    // 检查文字是否真的输入进去了，没输入就中止，防止乱点
    var typed = (input.textContent || '').trim();
    if (!typed) {
      log('error', 'text insertion failed, aborting send to prevent misclick');
      return false;
    }

    // 直接按 Enter 发送，最可靠
    input.focus();
    var enterEvent = new KeyboardEvent('keydown', {
      key: 'Enter', code: 'Enter', keyCode: 13,
      bubbles: true, cancelable: true
    });
    input.dispatchEvent(enterEvent);
    log('sent-enter', 'pressed Enter to send');
    await sleep(300);

    log('sent', text.slice(0, 80));
    return true;
  }

  // 返回发给服务端的新消息数量（非自己发的）
  // unreadHint：切换到一个新聊天时侧边栏显示的未读数，只处理最后这么多条消息
  // 剩下历史消息标为已处理不 POST，避免 reload 扩展后把整个对话历史都 POST
  // Cold-boot 保护：插件首次加载（processedIds 全空 = localStorage 没记录过）
  // 把当前可见消息全部标为已处理，避免把历史聊天全 POST 给云端
  var coldBootHandled = false;

  async function pollMessages(unreadHint) {
    var newMsgCount = 0;
    try {
      var chat = getCurrentChat();
      if (!chat) return 0;
      var messages = getVisibleMessages();

      // ── Cold-boot 保护 ──
      // 首次启动（processedIds 空）且看到一堆历史消息 → 全部标为已处理，跳过 POST
      // 之后到来的新消息才会被处理
      if (!coldBootHandled && processedIds.size === 0 && messages.length > 0) {
        messages.forEach(function(m) { processedIds.add(m.id); });
        _saveProcessedIds();
        coldBootHandled = true;
        log('coldboot', '首次启动，已将当前 ' + messages.length + ' 条可见历史消息标为已处理（不 POST）');
        return 0;
      }
      coldBootHandled = true;

      // 收集最近的可见消息作为上下文（最多取最后20条）
      var recentContext = [];
      var contextStart = Math.max(0, messages.length - 20);
      for (var c = contextStart; c < messages.length; c++) {
        var cm = messages[c];
        recentContext.push({
          fromMe: cm.fromMe,
          text: cm.text,
          sender: cm.sender
        });
      }

      // 如果传了 unreadHint（切换聊天触发），只处理最后 unreadHint 条客户消息
      // 前面的历史消息统统标记为已处理，不 POST
      var startIdx = 0;
      if (unreadHint && unreadHint > 0) {
        var customerMsgs = messages.filter(function(m) { return !m.fromMe; });
        if (customerMsgs.length > unreadHint) {
          var firstUnreadId = customerMsgs[customerMsgs.length - unreadHint].id;
          for (var k = 0; k < messages.length; k++) {
            if (messages[k].id === firstUnreadId) { startIdx = k; break; }
          }
          // 前面的历史消息全部加 processedIds 避免 POST
          for (var h = 0; h < startIdx; h++) {
            processedIds.add(messages[h].id);
          }
          _saveProcessedIds();
          log('skip-history', 'marked ' + startIdx + ' old messages as processed, only handling last ' + unreadHint + ' unread');
        }
      }

      for (var i = startIdx; i < messages.length; i++) {
        var msg = messages[i];
        if (processedIds.has(msg.id)) continue;
        processedIds.add(msg.id);
        _saveProcessedIds();
        if (processedIds.size > 5000) {
          var arr = Array.from(processedIds);
          arr.splice(0, 2000);
          processedIds.clear();
          arr.forEach(function(x) { processedIds.add(x); });
          _saveProcessedIds();
        }
        if (msg.fromMe) continue;
        newMsgCount++;
        // sender 为空时用 chatName 做 fallback（1对1私聊常见）
        var effectiveSender = msg.sender || chat.title || 'unknown';
        // chat title 是电话号码格式（+852 xxx / 纯数字空格）→ 强制判定私聊，不管 msg.sender
        // 避免 WhatsApp data-pre-plain-text 里即使是私聊也带发送者名导致误判为群聊
        var titleIsPhone = /^\+?[\d\s\-()]+$/.test((chat.title || '').trim());
        var isGroupMsg = titleIsPhone ? false : !!msg.sender;
        log('msg', '[' + chat.title + '] ' + effectiveSender + ': ' + msg.text.slice(0, 80) + (isGroupMsg ? ' [group]' : ' [private]'));
        // 雲端版：跳過老板私聊（隱私不上雲）
        if (bossChatName && chat.title === bossChatName && !isGroupMsg) {
          log('skip-boss', 'boss chat skipped (cloud mode)');
          continue;
        }
        // 用 chat title 的數字作 customer_id（私聊手機號 / 群聊用群名）
        var customerId = isGroupMsg ? chat.title : (chat.title || '').replace(/[^0-9]/g, '') || chat.title;
        try {
          var resp = await sbFetch('/functions/v1/wa-message', {
            method: 'POST',
            body: JSON.stringify({
              msg_id: msg.id,
              customer_id: customerId,
              chat_name: chat.title,
              is_group: isGroupMsg,
              sender: effectiveSender,
              content: msg.text,
              visible_context: recentContext,
              location: msg.location || null
            })
          });
          var data = await resp.json();
          log('server', data.duplicate ? 'duplicate' : (data.in_cooldown ? 'cooldown' : (data.pending_id ? 'queued #' + data.pending_id : 'ok')));
        } catch (err) {
          if (!lastPollTime) {
            log('info', 'cloud not reachable');
            lastPollTime = Date.now();
          }
        }
      }
    } catch (err) {
      log('poll-error', err.message);
    }
    return newMsgCount;
  }

  // ── 图片发送（雲端版不支持，函數保留但永遠不會被調用，pollReplies 只處理 text segment）──
  async function sendImage(imageUrl) {
    log('img-skip', 'cloud mode does not support images');
    return false;
    // 以下原本地版邏輯 dead code（雲端沒有 SERVER + 圖片存儲）
    // eslint-disable-next-line no-unreachable
    var imgResp = await fetch(SUPABASE_URL + imageUrl);
    var blob = await imgResp.blob();
    var fileName = imageUrl.split('/').pop() || 'image.jpg';
    var file = new File([blob], fileName, { type: blob.type || 'image/jpeg' });

    // 2. 找到附件 + 按钮（data-icon="plus-rounded" 或 aria-label="附加"）
    var attachBtn = document.querySelector('span[data-icon="plus-rounded"]')
      || document.querySelector('span[data-icon="plus"]')
      || document.querySelector('span[data-icon="attach-menu-plus"]')
      || document.querySelector('span[data-icon="clip"]');
    if (!attachBtn) {
      // fallback: 通过 aria-label 找
      attachBtn = document.querySelector('button[aria-label="附加"]')
        || document.querySelector('button[aria-label="Attach"]');
    }
    if (!attachBtn) {
      log('img-error', 'attachment button not found');
      return false;
    }

    var clickTarget = attachBtn.closest('button') || attachBtn;
    clickTarget.click();
    log('img', 'clicked attach button');
    await sleep(800);

    // 3. 点击"照片和视频"选项，先尝试找 file input
    var fileInput = document.querySelector('input[type="file"][accept*="image"]')
      || document.querySelector('input[type="file"][accept*="video"]');

    if (!fileInput) {
      // 在弹出菜单里找"照片和视频"文字，点击它
      var allSpans = document.querySelectorAll('span');
      for (var s = 0; s < allSpans.length; s++) {
        var spanText = (allSpans[s].textContent || '').trim();
        if (spanText === '照片和视频' || spanText === 'Photos & videos'
            || spanText === 'Photos and videos' || spanText === 'Photos & Videos') {
          // 点击包含这个文字的可点击父元素
          var clickable = allSpans[s].closest('[role="button"]')
            || allSpans[s].closest('div[tabindex]')
            || allSpans[s].closest('li')
            || allSpans[s].parentElement;
          if (clickable) {
            clickable.click();
            log('img', 'clicked "照片和视频" option');
            await sleep(600);
          }
          break;
        }
      }
      // 再找一次 file input
      fileInput = document.querySelector('input[type="file"][accept*="image"]')
        || document.querySelector('input[type="file"][accept*="video"]')
        || document.querySelector('input[type="file"]');
    }

    if (!fileInput) {
      log('img-error', 'file input not found, closing menu');
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      return false;
    }

    // 4. 用 DataTransfer 注入文件
    var dt = new DataTransfer();
    dt.items.add(file);
    fileInput.files = dt.files;
    fileInput.dispatchEvent(new Event('change', { bubbles: true }));
    log('img', 'file injected, waiting for preview...');
    await sleep(2500);

    // 5. 在预览界面找发送按钮（data-icon="wds-ic-send-filled" 或 aria-label="发送"）
    var sendIcon = document.querySelector('span[data-icon="wds-ic-send-filled"]')
      || document.querySelector('span[data-icon="send"]');
    if (sendIcon) {
      var sendBtn = sendIcon.closest('div[role="button"]') || sendIcon.closest('button');
      if (sendBtn) {
        sendBtn.click();
        log('img', 'send clicked in preview');
        await sleep(1000);
        return true;
      }
    }

    // fallback: 通过 aria-label 找发送按钮
    var previewBtns = document.querySelectorAll('div[role="button"][aria-label]');
    for (var p = 0; p < previewBtns.length; p++) {
      var label = (previewBtns[p].getAttribute('aria-label') || '');
      if (label === '发送' || label === 'Send') {
        previewBtns[p].click();
        log('img', 'send clicked via aria-label');
        await sleep(1000);
        return true;
      }
    }

    log('img-error', 'could not find send button in preview');
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    return false;
  }

  // 雲端版：短輪詢 wa_replies WHERE delivered_at IS NULL，逐條發送後 PATCH delivered_at
  async function pollReplies() {
    while (true) {
      try {
        var resp = await sbFetch('/rest/v1/wa_replies?delivered_at=is.null&select=*&order=created_at.asc&limit=5');
        var rows = await resp.json();
        if (Array.isArray(rows) && rows.length > 0) {
          for (var r = 0; r < rows.length; r++) {
            var row = rows[r];
            var segments = typeof row.segments === 'string' ? JSON.parse(row.segments) : row.segments;
            if (!Array.isArray(segments) || segments.length === 0) {
              // 空回復也標 delivered，避免反復拉
              await sbFetch('/rest/v1/wa_replies?id=eq.' + row.id, {
                method: 'PATCH',
                headers: { 'Prefer': 'return=minimal' },
                body: JSON.stringify({ delivered_at: new Date().toISOString(), delivery_meta: { reason: 'empty_segments' } })
              });
              continue;
            }
            if (row.chat_name) {
              await switchToChatByName(row.chat_name);
            }
            for (var i = 0; i < segments.length; i++) {
              var seg = segments[i];
              var text = typeof seg === 'string' ? seg : (seg.content || '');
              if (text) await sendMessage(text);
              if (i < segments.length - 1) await sleep(2000);
            }
            // 標 delivered
            await sbFetch('/rest/v1/wa_replies?id=eq.' + row.id, {
              method: 'PATCH',
              headers: { 'Prefer': 'return=minimal' },
              body: JSON.stringify({ delivered_at: new Date().toISOString() })
            });
            log('reply-done', 'reply #' + row.id + ' sent for: ' + (row.chat_name || row.customer_id));
            if (replyDoneResolve) replyDoneResolve('done');
          }
        }
      } catch (e) {
        log('poll-replies-err', e.message);
        await sleep(5000);
        continue;
      }
      await sleep(REPLY_POLL_INTERVAL);
    }
  }

  async function switchToChatByName(name) {
    var current = getCurrentChat();
    if (current && current.title === name) return;
    var chatItems = document.querySelectorAll('#pane-side [role="listitem"]');
    for (var i = 0; i < chatItems.length; i++) {
      var nameEl = chatItems[i].querySelector('span[dir="auto"][title]');
      var chatName = nameEl ? (nameEl.getAttribute('title') || nameEl.innerText || '').trim() : '';
      if (chatName === name) {
        clickViaReact(chatItems[i]);
        await sleep(2000);
        log('switch', 'back to: ' + name);
        return;
      }
    }
    log('warn', 'chat not found: ' + name);
  }

  function waitForLoad() {
    var check = setInterval(function() {
      var side = document.querySelector('#side');
      if (side) {
        clearInterval(check);
        log('ready', 'WhatsApp Web loaded');
        loadWhitelist();
        var existing = getVisibleMessages();
        existing.forEach(function(m) { processedIds.add(m.id); });
        _saveProcessedIds();
        log('init', 'skipped ' + existing.length + ' existing messages (total tracked: ' + processedIds.size + ')');
        setInterval(pollMessages, POLL_INTERVAL);
        setInterval(checkUnreadChats, UNREAD_CHECK_INTERVAL);
        pollReplies();
        // 雲端心跳：啟動立即一次 + 每 30s 一次（給 bizflow「在線雲端客戶端」狀態卡用）
        sendHeartbeat();
        setInterval(sendHeartbeat, HEARTBEAT_INTERVAL);
        log('running', 'poll + unread check + reply listener + heartbeat started (id=' + CLIENT_ID + ', v' + EXT_VERSION + ')');
      }
    }, 1000);
  }

  waitForLoad();
})();
